//
//  iTCARView.h
//  FingAR
//
//  Created by Faizan on 28/08/12.
//  Copyright (c) 2012 ronak@itechcoders.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "iTCAppDelegate.h"


//#import "MainViewController.h"

@interface iTCARView : UIViewController

{

    iTCAppDelegate *appDel;


}

- (IBAction)upLoadArClicked:(id)sender;
//@property (nonatomic, retain) MainViewController *mainViewController;


- (IBAction)cameraClicked:(id)sender;




@end
