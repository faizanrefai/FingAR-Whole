//
//  iTCARView.m
//  FingAR
//
//  Created by Faizan on 28/08/12.
//  Copyright (c) 2012 ronak@itechcoders.com. All rights reserved.
//

#import "iTCARView.h"
#import "iTCUploadView.h"
@interface iTCARView ()

@end

@implementation iTCARView
//@synthesize mainViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UIButton* backButton = [UIButton buttonWithType:UIButtonTypeCustom]; // left-pointing shape
    UIImage *img= [UIImage imageNamed:@"6_6.png"];
    [backButton setFrame:CGRectMake(5, 5,  img.size.width/2,img.size.height/2) ];
    //    [backButton addTarget:self action:@selector(backClick) forControlEvents:UIControlEventTouchUpInside];
    [backButton setImage:[UIImage imageNamed:@"6_6.png"] forState:UIControlStateNormal];
    // create button item
    UIBarButtonItem* backItem = [[UIBarButtonItem alloc] initWithCustomView:backButton]	;
    
    // add the button to navigation bar
    self.navigationItem.rightBarButtonItem = backItem;
    

    appDel = (iTCAppDelegate*)[[UIApplication sharedApplication]delegate];
    
    
    self.title = @"Feeds";
}

-(void)viewWillAppear:(BOOL)animated
{
    
    self.navigationController.navigationBarHidden=FALSE;
    
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)upLoadArClicked:(id)sender {
    iTCUploadView *obj = [[iTCUploadView alloc]initWithNibName:@"iTCUploadView" bundle:nil];
    [self.navigationController pushViewController:obj animated:YES];
    
}
- (IBAction)cameraClicked:(id)sender {
    
//    MainViewController *aController = [[MainViewController alloc] initWithNibName:@"MainView" bundle:nil];
//    mainViewController = aController;
//    [[UIApplication sharedApplication]setStatusBarHidden:TRUE];
    UIViewController *vi = [[UIViewController alloc]init];
    vi = [appDel augView];
    [self presentModalViewController:vi animated:YES];

}
@end
