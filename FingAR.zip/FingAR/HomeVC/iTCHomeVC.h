//
//  iTCHomeVC.h
//  FingAR
//
//  Created by Faizan on 28/08/12.
//  Copyright (c) 2012 ronak@itechcoders.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iTCHomeVC : UIViewController

{

    
    
}


- (IBAction)getStaredPressed:(id)sender;
- (IBAction)faceBookPressed:(id)sender;


@end
