//
//  iTCGetStared.h
//  FingAR
//
//  Created by Faizan on 28/08/12.
//  Copyright (c) 2012 ronak@itechcoders.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iTCGetStared : UIViewController
{


}

- (IBAction)searachPressed:(id)sender;




@end
