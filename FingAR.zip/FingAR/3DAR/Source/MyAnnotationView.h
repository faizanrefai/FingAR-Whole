//
//  MyAnnotationView.h
//  CustomCalloutMapView
//
//  Created by Jakob Ericsson on 2009-12-03.
//  Copyright 2009 JAKERI AB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface MyAnnotationView : MKAnnotationView {

}

@end
