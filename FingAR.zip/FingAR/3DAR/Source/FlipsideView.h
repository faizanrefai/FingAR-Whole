//
//  FlipsideView.h
//  Yorient
//
//  Created by P. Mark Anderson on 11/10/09.
//  Copyright Spot Metrix, Inc 2009. All rights reserved.
//

@interface FlipsideView : UIView {
	
}

@end
