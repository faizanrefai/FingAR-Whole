//
//  ThumbnailMarkerWithCalloutView.m
//

#import <UIKit/UIKit.h>
#import "SM3DAR.h"

@interface ThumbnailMarkerWithCalloutView : SM3DARIconMarkerView 
{
}

@end
