//
//  MainViewController.h
//  Yorient
//
//  Created by P. Mark Anderson on 11/10/09.
//  Copyright Spot Metrix, Inc 2009. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>
#import "SM3DAR.h" 
#import "AudioToolbox/AudioServices.h"
#import "YahooLocalSearch.h"
#import <MapKit/MapKit.h>
#import <SimpleGeo/SimpleGeo.h>
#import "BirdseyeView.h"
#import "ThumbnailCalloutFocusView.h"
#import "MyAnnotationView.h"
#import "JSONParserL.h"
#import "GdataParser.h"
@interface MainViewController : UIViewController <MKMapViewDelegate, SM3DARDelegate, CLLocationManagerDelegate, SearchDelegate> 
{
    IBOutlet UILabel *lblDistance;
	SystemSoundID focusSound;
	NSString *searchQuery;
    YahooLocalSearch *search;
    BOOL sm3darInitialized;
    UIView *focusedMarker;
    NSArray *searchStrings;
    NSInteger currentSearchIndex;

    int frndCnt;
    int meetingCnt;

    NSMutableArray *annValues;
    NSMutableArray *annotations;
    
    IBOutlet SM3DARMapView *mapView;
    IBOutlet UIView *hudView;
    IBOutlet ThumbnailCalloutFocusView *focusView; 
    IBOutlet UIActivityIndicatorView *spinner;
    
    SimpleGeo *simplegeo;
    BirdseyeView *birdseyeView;
    
    IBOutlet UIButton *toggleMapButton;
    SM3DARPointOfInterest *northStar;

    CLLocationAccuracy desiredLocationAccuracy;
    NSInteger desiredLocationAccuracyAttempts;
    BOOL acceptableLocationAccuracyAchieved;
    
    NSMutableArray *myfechedplaces;
    NSMutableArray *placesArr;
    double minLat;
    double minLon;
}

@property (nonatomic, retain) NSString *searchQuery;
@property (nonatomic, retain) YahooLocalSearch *search;
@property (nonatomic, retain) IBOutlet SM3DARMapView *mapView;
@property (nonatomic, retain) SimpleGeo *simplegeo;
- (IBAction)CloseARView:(id)sender;


-(void)getMyPlace;
-(void)finishGetData:(NSDictionary*)dictionary;
//-(void)getMeeting;
- (void)initSound;
- (void)playFocusSound;
- (void)runLocalSearch:(NSString*)query;
//- (void)addDirectionBillboardsWithFixtures;
- (void) fetchSimpleGeoPlaces:(NSString*)searchString;
- (IBAction) refreshButtonTapped;
- (IBAction) toggleMapButtonTapped:(UIButton *)sender;
- (void) addNorthStar;
- (void) loadPoints;

@end
