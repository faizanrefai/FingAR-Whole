//
//  iTCAppDelegate.h
//  FingAR
//
//  Created by Faizan on 28/08/12.
//  Copyright (c) 2012 ronak@itechcoders.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreMotion/CoreMotion.h>
#import "ListViewController.h"
#import "AugmentedGeoViewController.h"
#import "JSON.h"
#import "MapViewController.h"
#import "MarkerView.h"
#import "Radar.h"
#import "MoreViewController.h"
#import "SourceViewController.h"
  


@interface iTCAppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate,ARViewDelegate, CLLocationManagerDelegate>

{

    
    UIWindow *window;

    CLLocationManager * _locManager;
	UITabBarController *_tabBarController;
	CMMotionManager *motionManager;
	ListViewController * _listViewController;
	MapViewController * _mapViewController;
	AugmentedGeoViewController *augViewController;
	NSMutableArray * _data;
	JsonHandler * jHandler;
	UISlider * _slider;
	UISegmentedControl *_menuButton;
	IBOutlet UIView * menuView;
    UILabel * _valueLabel;
    UILabel * nordLabel;
    UILabel * maxRadiusLabel;
    MoreViewController * _moreViewController;
    SourceViewController * _sourceViewController;
@private
    BOOL beforeWasLandscape;
    IBOutlet UIView * notificationView;


}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController *navigationController;


@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;
@property (nonatomic, retain) CLLocationManager * locManager;
@property (nonatomic, retain) IBOutlet ListViewController * listViewController;
@property (nonatomic, retain) IBOutlet NSMutableArray * data;
@property (nonatomic, retain) IBOutlet MapViewController* mapViewController;
@property (nonatomic, retain) IBOutlet UISlider * slider;
@property (nonatomic, retain) IBOutlet UISegmentedControl * menuButton;
@property (nonatomic, retain) IBOutlet MoreViewController *moreViewController;
@property (nonatomic, retain) IBOutlet SourceViewController * sourceViewController;
@property (nonatomic, retain) IBOutlet UILabel * valueLabel;


-(void) iniARView;
- (MarkerView *)viewForCoordinate:(PoiItem *)coordinate;
-(void)initLocationManager;
-(void)mapData;
-(void)downloadData;
-(void) initControls;
-(BOOL)checkIfDataSourceIsEanabled: (NSString *)source;
-(void)setViewToLandscape:(UIView*)viewObject;
-(void)setViewToPortrait:(UIView*)viewObject;
-(UIViewController*)augView;






@end
