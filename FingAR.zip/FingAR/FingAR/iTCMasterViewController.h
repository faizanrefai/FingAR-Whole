//
//  iTCMasterViewController.h
//  FingAR
//
//  Created by Faizan on 28/08/12.
//  Copyright (c) 2012 ronak@itechcoders.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class iTCDetailViewController;

@interface iTCMasterViewController : UITableViewController

@property (strong, nonatomic) iTCDetailViewController *detailViewController;

@end
