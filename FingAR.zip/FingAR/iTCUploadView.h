//
//  iTCUploadView.h
//  FingAR
//
//  Created by Faizan on 28/08/12.
//  Copyright (c) 2012 ronak@itechcoders.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMessageComposeViewController.h>
#import "Dialog.h"

@interface iTCUploadView : UIViewController<MFMailComposeViewControllerDelegate>

{
    NSMutableArray *arrayToMail;
    Dialog *dialog;


}
- (IBAction)googlePlusCliking:(id)sender;
- (IBAction)facebboking:(id)sender;

- (IBAction)tweeterCliked:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *faceBookClicked;

-(IBAction) mailSentButtonPresed;

@end
